/*#include "player.h"
#include "sdlon_init.h"
#include "item.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
void enTeteBox();
void suivantBox();
void append(box** head_ref, sdlon new_data);
void displayBox(box* head);*/