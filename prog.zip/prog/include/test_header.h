void posi_test_print(int test, int verbose);
void nega_test_print(int test, int verbose);
void affiche_test(char * str, int verbose);
void affiche_fiability(char * str, int nb_data, float nb_gen, int verbose);