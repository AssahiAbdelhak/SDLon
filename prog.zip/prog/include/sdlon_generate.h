#include "sdlon_init.h"
#ifndef PROB
//macros
#define PROB 100
#define TRUE 1
#define FALSE 0

/**
déclaration des prototypes des fonctions
*/
extern sdlon generate_sdlon(int environement, int min_level, int difficulty);
#endif