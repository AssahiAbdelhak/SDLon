#include <stdlib.h>


extern enum directions  directions;
extern enum actions  actions;
extern int collision[4160];
extern int sol[4160];
extern int chemin[4160];
extern int porte;
extern int arbre[4160];
extern int objets[4160];
extern int buissons[4160];
extern int combat_sol[4160];
extern int combat_ciel[4160];
extern int combat_arbre[4160];
extern int market_1[1600];
extern int market_2[1600];
extern int market_3[1600];
extern int market_4[1600];
extern int market_5[1600];
extern int porte_market;
extern int store;
extern int dame;
extern int market_collision[1600];