<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="pokemon" tilewidth="16" tileheight="16" tilecount="20832" columns="16">
 <image source="D:/projet/pokemon_style.png" width="256" height="20832"/>
</tileset>
